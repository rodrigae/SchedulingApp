package Model;

/*Author: Anthony E Rodriguez
 *Date: 02/23/2019
 *Description: Contains the table model for mysql City
 */
public class City {

    private String cityId;
    private String city;
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}




}
